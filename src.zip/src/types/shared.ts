export interface TargetBucket {
    bucketName: string;
    bucketType: string;
    recordCount: number;
    totalAmount: number;
    label?: string;
}
"use client";

import CollectionsSummary from "@/components/collections/CollectionsSummary";

export default function CollectionsSummaryPage() {
    return <CollectionsSummary />;
}

"use client";

import CollectionsDetails from "@/components/collections/CollectionsDetails";

export default function CollectionsDetailsPage() {
    return <CollectionsDetails />;
}

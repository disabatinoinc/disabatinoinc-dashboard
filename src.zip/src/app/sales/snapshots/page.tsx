"use client";

import SalesSnapshots from "@/components/sales/SalesSnapshots";

export default function SalesSnapshotsPage() {
    return <SalesSnapshots />;
}
"use client";

import SalesSummary from "@/components/sales/SalesSummary";

export default function SalesSummaryPage() {
    return <SalesSummary />;
}

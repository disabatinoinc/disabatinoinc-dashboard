"use client";

import ProjectManagementDetails from "@/components/projectManagement/ProjectManagementDetails";

export default function ProjectManagementPage() {
    return <ProjectManagementDetails />;
}
